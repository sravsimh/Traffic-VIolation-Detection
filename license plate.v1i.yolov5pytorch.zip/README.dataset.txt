# license plate > 2023-08-22 9:32pm
https://universe.roboflow.com/vbit-ar2oi/license-plate-z58sd

Provided by a Roboflow user
License: MIT

